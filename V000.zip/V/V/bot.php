<?php
date_default_timezone_set('Asia/Baghdad');
if(!file_exists('config.json')){
	$token = readline('-Enter Token: ');
	$id = readline('-Enter Id: ');
	file_put_contents('config.json', json_encode(['id'=>$id,'token'=>$token]));
	
} else {
	$config = json_decode(file_get_contents('config.json'),1);
	$token = $config['token'];
	$id = $config['id'];
}

if(!file_exists('accounts.json')){
    file_put_contents('accounts.json',json_encode([]));
}
include 'index.php';
try {
	$callback = function ($update, $bot) {
		global $id;
		if($update != null){
		  $config = json_decode(file_get_contents('config.json'),1);
		  $config['filter'] = $config['filter'] != null ? $config['filter'] : 1;
      $accounts = json_decode(file_get_contents('accounts.json'),1);
			if(isset($update->message)){
				$message = $update->message;
				$chatId = $message->chat->id;
				$text = $message->text;
				if($chatId == $id){
					if($text == '/start'){
              $bot->sendMessage([
                  'chat_id'=>$chatId,
                  'text'=>"-Welcome . \n - To Your IG Bussines Tool. \n\n By ~ @BBPXX",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'اضافة حساب وهميツ','callback_data'=>'login']],
                          [['text'=>'طريقة سحب اليوزر❄','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد🌟','callback_data'=>'run'],['text'=>'ايقاف الفحص⚡','callback_data'=>'stop']],
                          [['text'=>'حالة الحساباتლ','callback_data'=>'status']],
                          [['text'=>'محتوا تعليمي📖','callback_data'=>'statusakil']],
                      ]
                  ])
              ]);   
          } elseif($text != null){
          	if($config['mode'] != null){
          		$mode = $config['mode'];
          		if($mode == 'addL'){
          		$ig = new ig(['file'=>'','account'=>['useragent'=>'Instagram 176.0.0.38.116 Android (23/6.0.1; 640dpi; 1440x2392; LGE/lge; RS988; h1; h1; en_US)']]);
          			list($user,$pass) = explode(':',$text);
          			list($headers,$body) = $ig->login($user,$pass);
          			// echo $body;
          			$body = json_decode($body);
          			if(isset($body->message)){
          				if($body->message == 'challenge_required'){
          					$bot->sendMessage([
          							'chat_id'=>$chatId,
          							'parse_mode'=>'markdown',
          							'text'=>"*Error*. \n - Challenge Required"
          					]);
          				} else {
          					$bot->sendMessage([
          							'chat_id'=>$chatId,
          							'parse_mode'=>'markdown',
          							'text'=>"*Error*.\n - Incorrect Username Or Password"
          					]);
          				}
          			} elseif(isset($body->logged_in_user)) {
          				$body = $body->logged_in_user;
          				preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $headers, $matches);
								  $CookieStr = "";
								  foreach($matches[1] as $item) {
								      $CookieStr .= $item."; ";
								  }
          				$account = ['cookies'=>$CookieStr,'useragent'=>'Instagram 176.0.0.38.116 Android (23/6.0.1; 640dpi; 1440x2392; LGE/lge; RS988; h1; h1; en_US)'];
          				
          				$accounts[$text] = $account;
          				file_put_contents('accounts.json', json_encode($accounts));
          				$mid = $config['mid'];
          				$bot->sendMessage([
          				      'parse_mode'=>'markdown',
          							'chat_id'=>$chatId,
          							'text'=>"*Done Add New Accounts To Your Tool.*\n _Username_ : [$user])(instagram.com/$user)\n_Account Name_ : _{$body->full_name}_",
												'reply_to_message_id'=>$mid		
          					]);
          				$keyboard = ['inline_keyboard'=>[
										[['text'=>"Add New Accounts",'callback_data'=>'addL']]
									]];
		              foreach ($accounts as $account => $v) {
		                  $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'ddd'],['text'=>"Logout",'callback_data'=>'del&'.$account]];
		              }
		              $keyboard['inline_keyboard'][] = [['text'=>'رجوع','callback_data'=>'back']];
		              $bot->editMessageText([
		                  'chat_id'=>$chatId,
		                  'message_id'=>$mid,
		                  'text'=>"Accounts Control Page.",
		                  'reply_markup'=>json_encode($keyboard)
		              ]);
		              $config['mode'] = null;
		              $config['mid'] = null;
		              file_put_contents('config.json', json_encode($config));
          			}
          		}  elseif($mode == 'selectFollowers'){
          		  if(is_numeric($text)){
          		    bot('sendMessage',[
          		        'chat_id'=>$chatId,
          		        'text'=>"تم التعديل.",
          		        'reply_to_message_id'=>$config['mid']
          		    ]);
          		    $config['filter'] = $text;
          		    $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                      'text'=>"-Welcome . \n - To Your IG Bussines Tool. \n\n By ~ @BBPXX",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'اضافة حساب وهميツ','callback_data'=>'login']],
                          [['text'=>'طريقة سحب اليوزر❄','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد🌟','callback_data'=>'run'],['text'=>'ايقاف الفحص⚡','callback_data'=>'stop']],
                          [['text'=>'حالة الحساباتლ','callback_data'=>'status']],
                          [['text'=>'محتوا تعليمي📖','callback_data'=>'statusakil']],
                      ]
                  ])
                  ]);
          		    $config['mode'] = null;
		              $config['mid'] = null;
		              file_put_contents('config.json', json_encode($config));
          		  } else {
          		    bot('sendMessage',[
          		        'chat_id'=>$chatId,
          		        'text'=>'- يرجى ارسال رقم فقط .'
          		    ]);
          		  }
          		} else {
          		  switch($config['mode']){
          		    case 'search': 
          		      $config['mode'] = null; 
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php search.php');
          		      break;
          		      case 'followers': 
          		      $config['mode'] = null; 
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php followers.php');
          		      break;
          		      case 'following': 
          		      $config['mode'] = null; 
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php following.php');
          		      break;
          		      case 'hashtag': 
          		      $config['mode'] = null; 
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php hashtag.php');
          		      break;
          		  }
          		}
          	}
          }
				} else {
					$bot->sendMessage([
							'chat_id'=>$chatId,
							'text'=>"داة صيد متاحات انستكرام عربيه
لشرا نسخه عضويه او ملفات راسلنا. ",
							'reply_markup'=>json_encode([
                  'inline_keyboard'=>[
                      [['text'=>'• المطـور','url'=>'t.me/BBPXX']]
                  ]
							])
					]);
				}
			} elseif(isset($update->callback_query)) {
          $chatId = $update->callback_query->message->chat->id;
          $mid = $update->callback_query->message->message_id;
          $data = $update->callback_query->data;
          echo $data;
          if($data == 'login'){
              
        		$keyboard = ['inline_keyboard'=>[
										[['text'=>"Add New Accounts",'callback_data'=>'addL']]
									]];
		              foreach ($accounts as $account => $v) {
		                  $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'ddd'],['text'=>"Logout",'callback_data'=>'del&'.$account]];
		              }
		              $keyboard['inline_keyboard'][] = [['text'=>'رجوع','callback_data'=>'back']];
		              $bot->editMessageText([
		                  'chat_id'=>$chatId,
		                  'message_id'=>$mid,
		                  'text'=>"Accounts Control Page.",
		                  'reply_markup'=>json_encode($keyboard)
		              ]);
          } elseif($data == 'addL'){
          	
          	$config['mode'] = 'addL';
          	$config['mid'] = $mid;
          	file_put_contents('config.json', json_encode($config));
          	$bot->sendMessage([
          			'chat_id'=>$chatId,
          			'text'=>"Send Account Like : \n `user:pass`",
          			'parse_mode'=>'markdown'
          	]);
          } elseif($data == 'grabber'){
            
            $for = $config['for'] != null ? $config['for'] : 'حدد الحساب';
            $count = count(explode("\n", file_get_contents($for)));
            $bot->editMessageText([
                'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"Users collection page. \n - Users : $count \n - For Account : $for",
                'reply_markup'=>json_encode([
                    'inline_keyboard'=>[
                        [['text'=>' سحب من البحث©','callback_data'=>'search']],
                        [['text'=>' سحب من الهشتاكات🌀','callback_data'=>'hashtag'],['text'=>'💡 سحب من الاكسبلور','callback_data'=>'explore']],
                        [['text'=>'followers👥','callback_data'=>'followers'],['text'=>"following👤",'callback_data'=>'following']],
                        [['text'=>"تحديد حساب : $for",'callback_data'=>'for']],
                        [['text'=>' لسته جديده🌟','callback_data'=>'newList'],['text'=>' لسته قديمة⭐','callback_data'=>'append']],
                        [['text'=>' رجوع🔚','callback_data'=>'back']],
                    ]
                ])
            ]);
          } elseif($data == 'search'){
            $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"الان ارسل كلمات البحث لتم فحصهم \n يمكنك ارسال اكثر من كلمه من خلال وضع مسافه بينهم"
            ]);
            $config['mode'] = 'search';
            file_put_contents('config.json', json_encode($config));
          } elseif($data == 'followers'){
            $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"الان ارسل اليوزر لتم فحص اليتابعهم \n يمكنك ارسال اكثر من يوزر من خلال وضع مسافه بينهم"
            ]);
            $config['mode'] = 'followers';
            file_put_contents('config.json', json_encode($config));
          } elseif($data == 'following'){
            $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"الان ارسل اليوزر لتم فحص المتابعين \n يمكنك ارسال اكثر من يوزر من خلال وضع مسافه بينهم"
            ]);
            $config['mode'] = 'following';
            file_put_contents('config.json', json_encode($config));
          } elseif($data == 'hashtag'){
            $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"الان ارسل الهشتاكات بدون العلامه # \nيمكنك ارسال هشتاك واحد"
            ]);
            $config['mode'] = 'hashtag';
            file_put_contents('config.json', json_encode($config));
          } elseif($data == 'newList'){
            file_put_contents('a','new');
            $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"Done Select New List.",
							'show_alert'=>1
						]);
          } elseif($data == 'append'){ 
            file_put_contents('a', 'ap');
            $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"Done Select Exsist list.",
							'show_alert'=>1
						]);
						
          } elseif($data == 'for'){
            if(!empty($accounts)){
            $keyboard = [];
             foreach ($accounts as $account => $v) {
                $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'forg&'.$account]];
              }
              $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"Select Account.",
                  'reply_markup'=>json_encode($keyboard)
              ]);
            } else {
              $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"Add Account First.",
							'show_alert'=>1
						]);
            }
          } elseif($data == 'selectFollowers'){
            bot('sendMessage',[
                'chat_id'=>$chatId,
                'text'=>'قم بأرسال عدد متابعين .'  
            ]);
            $config['mode'] = 'selectFollowers';
          	$config['mid'] = $mid;
          	file_put_contents('config.json', json_encode($config));
          } elseif($data == 'run'){
            if(!empty($accounts)){
            $keyboard = [];
             foreach ($accounts as $account => $v) {
                $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'start&'.$account]];
              }
              $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"Select Account.",
                  'reply_markup'=>json_encode($keyboard)
              ]);
            } else {
              $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"Add Account First.",
							'show_alert'=>1
						]);
            }
          }elseif($data == 'stop'){
            if(!empty($accounts)){
            $keyboard = [];
             foreach ($accounts as $account => $v) {
                $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'stop&'.$account]];
              }
              $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"Select Account.",
                  'reply_markup'=>json_encode($keyboard)
              ]);
            } else {
              $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"Add Account First.",
							'show_alert'=>1
						]);
            }
          }elseif($data == 'stopgr'){
            shell_exec('screen -S gr -X quit');
            $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"Done Stop Collecting.",
						// 	'show_alert'=>1
						]);
						$for = $config['for'] != null ? $config['for'] : 'Select Account';
                        $count = count(explode("\n", file_get_contents($for)));
						$bot->editMessageText([
                'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"Users collection page. \n - Users : $count \n - For Account : $for",
                'reply_markup'=>json_encode([
                    'inline_keyboard'=>[
                        [['text'=>' سحب من البحث©','callback_data'=>'search']],
                        [['text'=>' سحب من الهشتاكات🌀','callback_data'=>'hashtag'],['text'=>'💡 سحب من الاكسبلور','callback_data'=>'explore']],
                        [['text'=>'followers👥','callback_data'=>'followers'],['text'=>"following👤",'callback_data'=>'following']],
                        [['text'=>"تحديد حساب : $for",'callback_data'=>'for']],
                        [['text'=>' لسته جديده🌟','callback_data'=>'newList'],['text'=>' لسته قديمة⭐','callback_data'=>'append']],
                        [['text'=>' رجوع🔚','callback_data'=>'back']],
                    ]
                ])
            ]);
          } elseif($data == 'explore'){
            exec('screen -dmS gr php explore.php');
          } elseif($data == 'status'){
					$status = '';
					foreach($accounts as $account => $ac){
						$c = explode(':', $account)[0];
						$x = exec('screen -S '.$c.' -Q select . ; echo $?');
						if($x == '0'){
				        $status .= "*$account* ~> _Working_\n";
				    } else {
				        $status .= "*$account* ~> _Stop_\n";
				    }
					}
					$bot->sendMessage([
							'chat_id'=>$chatId,
							'text'=>"Accounts Status: \n\n $status",
							'parse_mode'=>'markdown'
						]);
				} elseif($data == 'back'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                      'text'=>"-Welcome . \n - To Your IG Bussines Tool. \n\n By ~ @BBPXX",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'اضافة حساب وهميツ','callback_data'=>'login']],
                          [['text'=>'طريقة سحب اليوزر❄','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد🌟','callback_data'=>'run'],['text'=>'ايقاف الفحص⚡','callback_data'=>'stop']],
                          [['text'=>'حالة الحساباتლ','callback_data'=>'status']],
                          [['text'=>'محتوا تعليمي📖','callback_data'=>'statusakil']],
                      ]
                  ])
                  ]);
                  
                  } elseif($data == 'statusakil'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "ولأن لقد تم اضافة ازرار تعليمية للذين يواجهون صعوبه في معرفة كيفية عمل البوت 
للاستفسار او لتقديم الملاحضات يرجا مراسلة المطور
» @BBPXX «",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'شرح المتاحات📖','callback_data'=>'mot1']],
                          [['text'=>'رابط سحب متاح الهوتميل👾','callback_data'=>'mot2']],
                          [['text'=>'فيديو1💙','callback_data'=>'mot3'],['text'=>'فيديو 2💚','callback_data'=>'mot4']],
                          [['text'=>'بصمة1💛','callback_data'=>'mot5'],['text'=>'بصمة2💜','callback_data'=>'mot6']],
                          [['text'=>'حقوق البوت🎟','callback_data'=>'mot7']],
 [['text'=>' °•قناتي•°','url'=>'t.me/akil828'],['text'=>'°•المطور•°','url'=>'t.me/BBPXX']],
 [['text'=>'رجوع','callback_data'=>'back']],
                      ]
                  ])
                  ]);				
						
						
						                  } elseif($data == 'mot1'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "السلام عليكم

الأن سوف اعرفكم ما هو المتاح وكيفية سحبه😁❤

المتاح يا ساده وبشكل مختصر المتاح هو حساب  منشئ علا بريد الكتروني مؤقت او غير موجود

أذا لم تفهم بعد

حسناً : يعني هناك شخص ما قد قام بعمل حساب علا INSTAGRAM ولقد قام بعمل هاذا الحساب علا بريد الكتروني وهمي يعني غير موجود او لقد قام بعمل هاذا الحساب علا بريد الكتروني ولم يقم بنشاط علا البريد لمده زمنيه اطول من سنه وبهاذا تقوم الخوادم بحذف البريد من قاعدة البيانات تلقأين✅

وبذالك يمكنك انت عمل بريد الكتروني بنفس الاسم 
وطلب Rest يعني رسالة استعاده او اعادة تعيين كلمة المرور

وسوف تصلك الرساله علا نفس البريد الذي انشأته

كيف تعرف البريد الأكتروني وكيف تعرف نوع الدومين
وكيف تقوم بسحب المتاح؟!

حسناً هاذا الأداه تقوم بصيد حسابات الـ INSTAGRAM
وعندما تقوم بصيد تضهر يوزر الحساب ول ايميل وعدد المتابعين وعدد المتابعهم وعدد البوستات
مثال🎗
𝐇𝐈 حٍِٰـﮧِۢزنِٰـﮧِۢ 𝐍𝐄𝐖 𝐅𝐔𝐂𝐊𝐄𝐃🕵🎣 
━━━━━━━━━━━━━━━━━━━━
.✿.𝕌𝕊𝔼ℝ : aprendatevenda
.✿.𝔼𝕄𝔸𝕀𝕃 : aprendapostea@yahoo.com
.✿.𝔽𝕆𝕃𝕃𝕆𝕎𝔼ℝ𝕊 : 30635
.✿.𝔽𝕆𝕃𝕃𝕆𝕎𝕀ℕ𝔾 : 1
.✿.ℙ𝕆𝕊𝕋 : 15
.✿.ℍ𝕆𝕌ℝ : 2021/4/7 4:04
━━━━━━━━━━━━━━━━━━━━
𝐓𝐄𝐋𝐄 : @BBPXX ლ 𝐓𝐄𝐋𝐄 : @akil828


انت تقوم بأخذ الأيميل هاذا الأيميل
aprendapostea@yahoo.com
وتقوم بنضر ألا نوع الدومين هل هوا 
ياهو أو جيميل أو هوتميل أو ايميل روسي
هاذا الحساب الذي لدينا ياهو
اذا سوف نذهب ألا موقع ياهو ونقوم بتسجيل حساب جديد بأسم الحساب الذي قمنا بصيده
 
ثم نقوم بطلب رمز Rest من INSTAGRAM

وسوف تجد الرساله في البريد الذي انشأته
وقم بأخذ الحساب ومبروك 😁😁❤

@BBPXX
🌹🌹🌹🌹🌹🌹🌹🌹🌹🌹🌹🌹🌹🌹🌹🌹",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'رجوع','callback_data'=>'statusakil']],
                          ]
                  ])
                  ]);
                  
												
						} elseif($data == 'mot2'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "رابط هوتيمل قديم ما تحتاج رقم هاتف ولا غيرو كل الي عليك انك تحط الاحرفالي تراها بلكبتال وسلامتك😁 الرابط👇
                     
                     https://signup.live.com/signup?lcid=1033&wa=wsignin1.0&rpsnv=13&ct=1504132238&rver=6.7.6640.0&wp=MBI_SSL&wreply=https%3A%2F%2Foutlook.live.com%2Fowa%2F%3Fnlp%3D1%26signup%3D1%26authRedirect%3Dtrue%26RpsCsrfState%3Df350c55d-4b3a-b9c7-ed28-dcdf2e9f47f7&id=292841&CBCXT=out&fl=wld&pcexp=false&cobrandid=90015&uaid=130c9ab91ce74ebd97397561ca52fe89&lic=1






@BBPXX   ❤❤❤❤❤❤❤❤❤❤❤❤
                    ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'رجوع','callback_data'=>'statusakil']],
                          ]
                  ])
                  ]);
                  
                  } elseif($data == 'mot3'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "https://t.me/FOLLOW_NAFSEA/163",
						'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'رجوع','callback_data'=>'statusakil']],
                          ]
                  ])
                  ]);
                  
                  } elseif($data == 'mot4'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "https://t.me/FOLLOW_NAFSEA/162",
						'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'رجوع','callback_data'=>'statusakil']],
                          ]
                  ])
                  ]);
                  
                  } elseif($data == 'mot5'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "https://t.me/FOLLOW_NAFSEA/160",
						'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'رجوع','callback_data'=>'statusakil']],
                          ]
                  ])
                  ]);
                  
                  } elseif($data == 'mot6'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "https://t.me/FOLLOW_NAFSEA/147",
						'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'رجوع','callback_data'=>'statusakil']],
                          ]
                  ])
                  ]);
                  
                  } elseif($data == 'mot7'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "بسم الله الرحمن الرحيم❤
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
•طبعا هاض الملف يعتبر اصدار V6.🌟
•الملف حينشر بشكل مجاني للجميع.❤
•ممنوع بيعه أبداااااا.🚫🚫
•المميزات الجديده.🔥
~ تحديث الأتصالات.✅
~تغيير ديكور الملف.✅
~اضافة ازرار تعليميه.✅
~تم اصلا مشكلة التفعيل من termax. ✅
• طبعا الملف ما انشر قبل هيك يعني اي شخص ينشرو 
معناها خماط.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
معرف مطور البوت 
» @BBPXX «",
						'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'رجوع','callback_data'=>'statusakil']],
                          ]
                  ])
                  ]);
                  
						
          } else {
          	$data = explode('&',$data);
          	if($data[0] == 'del'){
          		
          		unset($accounts[$data[1]]);
          		file_put_contents('accounts.json', json_encode($accounts));
              $keyboard = ['inline_keyboard'=>[
							[['text'=>"Add New Accounts",'callback_data'=>'addL']]
									]];
		              foreach ($accounts as $account => $v) {
		                  $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'ddd'],['text'=>"Logout",'callback_data'=>'del&'.$account]];
		              }
		              $keyboard['inline_keyboard'][] = [['text'=>'رجوع','callback_data'=>'back']];
		              $bot->editMessageText([
		                  'chat_id'=>$chatId,
		                  'message_id'=>$mid,
		                  'text'=>"Accounts Control Page.",
		                  'reply_markup'=>json_encode($keyboard)
		              ]);
          	} elseif($data[0] == 'forg'){
          	  $config['for'] = $data[1];
          	  file_put_contents('config.json',json_encode($config));
              $for = $config['for'] != null ? $config['for'] : 'Select';
              $count = count(explode("\n", file_get_contents($for)));
              $bot->editMessageText([
                'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"Users collection page. \n - Users : $count \n - For Account : $for",
                'reply_markup'=>json_encode([
                    'inline_keyboard'=>[
                        [['text'=>' سحب من البحث©','callback_data'=>'search']],
                        [['text'=>' سحب من الهشتاكات🌀','callback_data'=>'hashtag'],['text'=>'💡 سحب من الاكسبلور','callback_data'=>'explore']],
                        [['text'=>'followers👥','callback_data'=>'followers'],['text'=>"following👤",'callback_data'=>'following']],
                        [['text'=>"تحديد حساب : $for",'callback_data'=>'for']],
                        [['text'=>' لسته جديده🌟','callback_data'=>'newList'],['text'=>' لسته قديمة⭐','callback_data'=>'append']],
                        [['text'=>' رجوع🔚','callback_data'=>'back']],
                    ]
                ])
            ]);
          	} elseif($data[0] == 'start'){
          	  file_put_contents('screen', $data[1]);
          	  $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                      'text'=>"-Welcome . \n - To Your IG Bussines Tool. \n\n By ~ @BBPXX",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'اضافة حساب وهميツ','callback_data'=>'login']],
                          [['text'=>'طريقة سحب اليوزر❄','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد🌟','callback_data'=>'run'],['text'=>'ايقاف الفحص⚡','callback_data'=>'stop']],
                          [['text'=>'حالة الحساباتლ','callback_data'=>'status']],
                          [['text'=>'محتوا تعليمي📖','callback_data'=>'statusakil']],
                      ]
                  ])
                  ]);
              exec('screen -dmS '.explode(':',$data[1])[0].' php start.php');
              $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"*Start Checking.*\n Account: `".explode(':',$data[1])[0].'`',
                'parse_mode'=>'markdown'
              ]);
          	} elseif($data[0] == 'stop'){
          	  $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                      'text'=>"-Welcome . \n - To Your IG Bussines Tool. \n\n By ~ @BBPXX",
                      'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'اضافة حساب وهميツ','callback_data'=>'login']],
                          [['text'=>'طريقة سحب اليوزر❄','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد🌟','callback_data'=>'run'],['text'=>'ايقاف الفحص⚡','callback_data'=>'stop']],
                          [['text'=>'حالة الحساباتლ','callback_data'=>'status']],
                          [['text'=>'محتوا تعليمي📖','callback_data'=>'statusakil']],
                      ]
                    ])
                  ]);
              exec('screen -S '.explode(':',$data[1])[0].' -X quit');
          	}
          }
			}
		}
	};
	$bot = new EzTG(array('throw_telegram_errors'=>false,'token' => $token, 'callback' => $callback));
} catch(Exception $e){
	echo $e->getMessage().PHP_EOL;
	sleep(1);
}
